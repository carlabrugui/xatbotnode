/** navbar.js
 *
 * @version 1.0
 * @requires bootstrap.min.js
 * @requires bootstrap.css
 * @requires navbar.css
 */

/** renderNode()
 *
 * Facilitates creations of navigation menus by building properly structured
 * and linked navigation nodes. Recursive functionality allows this menu
 * to build sub-elements to an unlimited depth.
 *
 * @param {int} id - the id of the menu item as retrieved from SCS object
 * @param {HTMLElement} navBar - navbar DOM object
 * @param {bool} top - adds "dropdown-submenu" class if false, "dropdown" class if true
 * @param {bool} last - adds "last" class to menu item for styling
 * @param {bool} current - adds current class to menu item for styling
 * @param {bool} recursive - toggle recursive fucntion to build sub-menu items
 * @returns {bool} elementSelected - true if sub-menu item has been selected
 */
function renderNode(id, navBar, top, last, current, recursive) {
	var elementSelected = false;
	if (id >= 0) {
		var navNode = SCS.structureMap[id];
		if (navNode && ((typeof navNode.hideInNavigation != "boolean") || (navNode.hideInNavigation === false))) {
			var navItem = document.createElement("li");
			if (navNode.children.length > 0 && !top) {
				navItem.classList.add("dropdown-submenu");
			} else {
				navItem.classList.add("dropdown");
			}

			/*  Flag menu with class "current" if the page is active */
			if (current) {
				navItem.classList.add("current");
			}

			/*  Flag menu with class "last" if this is the last navigation item */
			if (last) {
				navItem.classList.add("last");
			}

			/*  Add text node which will display navigation item name */
			var navText = document.createTextNode(navNode.name);
			/*  Create href link for menu item and add styling flags */
			var navLink = document.createElement("a");
			navLink.classList.add("dropdown-toggle");
			navLink.setAttribute('data-hover', 'dropdown');
			/*  Add text node which will display navigation item name */
			var linkData = SCSRenderAPI.getPageLinkData(navNode.id) || {};
			if (linkData.href) {
				navLink.href = linkData.href;
			}
			if (linkData.target) {
				navLink.target = linkData.target;
			}

			navLink.appendChild(navText);
			navItem.appendChild(navLink);
			if (navNode.children.length > 0 && recursive) {
				var navSub = document.createElement("ul");
				navSub.classList.add("dropdown-menu");
				for (var c = 0; c < navNode.children.length; c++) {
					var subcurrent = (SCS.navigationCurr === navNode.children[c]) ? true : false;
					if (subcurrent) {
						navItem.classList.add("currParent");
						elementSelected = true;
					}

					if (renderNode(navNode.children[c], navSub, false, false, subcurrent, true)) {
						navItem.classList.add("currParent");
						elementSelected = true;
					}
				}

				navItem.appendChild(navSub);
			}
			navBar.appendChild(navItem);
		}
	}
	return elementSelected;
}

/** renderNav()
 *
 *	Main method for instantiating menu.  It must be called using event listener
 *	to ensure that both the DOM and the SCS object are available.  Navigation items are
 *	derived from the SCS object and iteratively constructed using renderNode method.  The
 *	result is appended to an empty div in the DOM with id of "topnav"
 **/

function renderNav()
{
	var topnav = document.getElementById("topnav"); // expected to be an empty <div>
	if (topnav) {
		var navBar = document.createElement("ul");
		navBar.classList.add("nav");
		navBar.classList.add("navbar-nav");
		//Add Home page menu to navbar
		var current = (SCS.navigationCurr === SCS.navigationRoot) ? true : false;
		renderNode(SCS.navigationRoot, navBar, true, false, current, false);
		var children = SCS.structureMap[SCS.navigationRoot].children;
		for (var i = 0; i < children.length; i++) {
			current = (SCS.navigationCurr === children[i]) ? true : false;
			var last = (i === children.length - 1) ? true : false;
			renderNode(children[i], navBar, true, last, current, true);
		}

		topnav.appendChild(navBar);
	}
}

/**	linkNavigation()
 *
 *	Creates a link that is attached to the site's "logo" corporate identity element.
 *	This method is necessary because URL structures are very different in public and
 *	edit modes
 *
 **/

function linkNavigation() {
	var sitesRoot = SCSRenderAPI.getPageLinkData(SCS.navigationRoot).href;
	$(".logocontainer").wrap("<a href='" + sitesRoot + "'>");
}

/***
 *	The following code will provide the necessary delays to ensure that both DOM
 *	and SCS properties are available to the script.
 *
 *	To use this code in another template, simply include /path/to/navbar.js in a template
 *	that contains an empty div with id = "topnav".
 **/

if (document.addEventListener) {
	document.addEventListener('scsrenderstart', renderNav, false);
}
else if (document.attachEvent) {
	document.documentElement.scsrenderstart = 0;
	document.documentElement.attachEvent("onpropertychange", function(event) {
		if (event && (event.propertyName == "scsrenderstart"))
		{
			renderNav();
			linkNavigation();
		}
	});
}
